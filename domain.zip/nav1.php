
<div class="navsec">
    <div class="container-fluid navsection" style="background-color: rgba(12, 98, 175, 1);">
        <div class="container">
            <nav class="navbar navbar-expand-lg" style="">
                <div class="logo_text" style="">
                    <a class="navbar-brand" style="color: #ffff;font-size: 32px;font-weight: 700;" href="#">Logo</a>
                </div>
                <style>
                   
                    .sec91{
                        display: flex;
                    align-items: center;
                    column-gap:30px;

                    }
                    </style>
                <div class="sec91">

                    <div class="nav-item mob_show_inr" style="">
                                <div onclick="opendrop_n(this)" class="dropup">
                                    <button class="dropbtn_n">
                                        <div id="val1_n" style="font-size: 14px !important;font-weight: 600 !important">
                                            INR
                                        </div>
                                        <i class="fa-solid fa-angle-down"></i>
                                    </button>
                                    <div class="dropup-content_n" style="display:none">
                                        <div class="dd-cont_n">
                                            <a href="#" class="result" onclick="change_n(this)">
                                                <img class="flag img-fluid"
                                                    src="http://www.jankoatwarpspeed.com/wp-content/uploads/examples/reinventing-drop-down/br.png"
                                                    alt="" />
                                                <div>USD</div>
                                            </a>
                                            <a href="#" class="result" onclick="change_n(this)">
                                                <img class="flag img-fluid"
                                                    src="http://www.jankoatwarpspeed.com/wp-content/uploads/examples/reinventing-drop-down/fr.png"
                                                    alt="" />
                                                <div>IND</div>
                                            </a>
                                            <a href="#" class="result" onclick="change_n(this)"> <img class="flag img-fluid"
                                                    src="http://www.jankoatwarpspeed.com/wp-content/uploads/examples/reinventing-drop-down/br.png"
                                                    alt="" />
                                                <div>AUS</div>
                                            </a>
                                            <a href="#" class="result" onclick="change_n(this)"> <img class="flag img-fluid"
                                                    src="http://www.jankoatwarpspeed.com/wp-content/uploads/examples/reinventing-drop-down/fr.png"
                                                    alt="" />
                                                <div>UAE</div>
                                            </a>
                                            <a href="#" class="result" onclick="change_n(this)"> <img class="flag img-fluid"
                                                    src="http://www.jankoatwarpspeed.com/wp-content/uploads/examples/reinventing-drop-down/br.png"
                                                    alt="" />
                                                <div>NZ</div>
                                            </a>
    
                                        </div>
                                    </div>
                                </div>
                            </div>
    

                    <div>
                        <button style="border:none" class="navbar-toggler" onclick="navopen()" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                    </div>
                </div>
                <div class="collapse navbar-collapse mob1_collapse" id="navbarSupportedContent" style="justify-content: end;">
                    <ul class="navbar-nav mr-auto" style="">
                        <li class="nav-item active" style="">
                            <a class="nav-link nav_a" href="index.php"
                                style=" ">
                                Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item" style="">
                            <a class="nav-link nav_a " href="#"
                                style=" ">FAQs</a>
                        </li>
                        <!-- <li class="nav-item" style="">
                            <a class="nav-link nav_a" href="#"
                                style="    ">Contact
                                </a>
                        </li> -->

                        <li class="nav-item desk_show_inr" style="">
                            <div onclick="opendrop_n(this)" class="dropup">
                                <button class="dropbtn_n">
                                    <div id="val1_n_d" style="font-size: 16px !important;font-weight: 600 !important">
                                        INR
                                    </div>
                                    <i class="fa-solid fa-angle-down"></i>
                                </button>
                                <div class="dropup-content_n" style="display:none">
                                    <div class="dd-cont_n">
                                        <a href="#" class="result" onclick="change_n(this)">
                                            <img class="flag img-fluid"
                                                src="http://www.jankoatwarpspeed.com/wp-content/uploads/examples/reinventing-drop-down/br.png"
                                                alt="" />
                                            <div style="font-weight: 600;
    font-size: 14px;">USD</div>
                                        </a>
                                        <a href="#" class="result" onclick="change_n(this)">
                                            <img class="flag img-fluid"
                                                src="http://www.jankoatwarpspeed.com/wp-content/uploads/examples/reinventing-drop-down/fr.png"
                                                alt="" />
                                            <div>IND</div>
                                        </a>
                                        <a href="#" class="result" onclick="change_n(this)"> <img class="flag img-fluid"
                                                src="http://www.jankoatwarpspeed.com/wp-content/uploads/examples/reinventing-drop-down/br.png"
                                                alt="" />
                                            <div style="font-weight: 600;
    font-size: 14px;">AUS</div>
                                        </a>
                                        <a href="#" class="result" onclick="change_n(this)"> <img class="flag img-fluid"
                                                src="http://www.jankoatwarpspeed.com/wp-content/uploads/examples/reinventing-drop-down/fr.png"
                                                alt="" />
                                            <div style="font-weight: 600;
    font-size: 14px;">UAE</div>
                                        </a>
                                        <a href="#" class="result" onclick="change_n(this)"> <img class="flag img-fluid"
                                                src="http://www.jankoatwarpspeed.com/wp-content/uploads/examples/reinventing-drop-down/br.png"
                                                alt="" />
                                            <div style="font-weight: 600;
    font-size: 14px;">NZ</div>
                                        </a>

                                    </div>
                                </div>
                            </div>
                        </li>
                        <style>
                             .useritem{
                                position: relative;
                            }
                            .useritem .user_m{
                                color: #ffff;position: relative;color: #ffff;
                                height: 35px;width:85px;border: 1px solid #ffff;
                                border-radius: 4px;
                                /* display:flex; */
                                justify-content:space-evenly;
                                align-items:center;
                            }
                            @media(max-width:992px){
                                .useritem .user_m{
                                border: 1px solid rgba(12, 98, 175, 1);
                               
                            }
                            
                            }
                            
                            #user{
                                /* display: none; */
                            }
                            .useritem .profile{
                                color: #ffff;font-size: 16px !important;font-weight: 600 !important;padding: 0 !important;
                            }
                            .useritem #profileside{
                                display:none;
                            }

                            @media(min-width:992px){
                            .useritem{
                                position: relative;
                            }
                           
                            .useritem #user{
                                color: #ffff;position: relative;color: #ffff;
                                height: 35px;width:85px;border: 1px solid #ffff;
                                border-radius: 4px;
                                /* display:flex; */
                                justify-content:space-around;
                                align-items:center;
                            }
                            .user{
                                /* display:none; */
                            }
                          
                            .useritem #profile{
                                color: #ffff;font-size: 16px !important;font-weight: 600 !important;padding: 0 !important;
                            }
                            .useritem #profileside{
                                margin-top: 3px;width: 250px;position: absolute;
                                top:57px;right:0%;background-color: #ffff;
                                text-align: center;z-index: 1;padding: 5px;
                                box-shadow: 0px 0px 22px -10px;
                                display:block;
                            }
                            } 
                            nav ul{
                                    flex-direction: column;
                                    row-gap: 30px;
                                    justify-content: start;
                                }

                                @media (min-width:992px) {
                                    .nav ul {
                                        /* flex-direction: row; */
                                        /* column-gap: 30px !important; */
                                        /* align-items: center; */
                                    }
                                }
                                @media (min-width: 992px){
                                    .navbar-expand-lg .navbar-nav {
                                        /* flex-direction: row; */
                                        column-gap:50px;
                                        align-items: center;
                                    }}
                                    
                                       
                                
                        </style>

                        <li class="nav-item useritem" style=" position:relative">
                        
                            <!-- <div  class="mob_show user_m">
                                <i  class="fa-solid fa-user" nav_i></i>
                                <div id="profile ">
                                    <button style="border:none;background: transparent;">
                                        <a href="ac-info.php" class="nav_a" style="">Profile</a>
                                    </button>
                                    </div>
                            </div> -->

                            <!-- d 992 -->
                            <div id="user"  class="desk_show" onclick="openprof()">
                            <i style="color:#fff" class="fa-solid fa-user"></i>
                            <div id="profile">
                                <button style="border: none;
                                background: transparent;color:#ffff;font-size:16px;font-weight:600px;">Profile</button></div>
                            </div>
                                <style>
                                    .mob_show{
                                        display:flex !important;

                                    }
                                    .desk_show{
                                        display:none !important;
                                    }
                                    @media(min-width:992px){
                                      
                                    .mob_show{
                                        display:none !important;

                                    }  
                                    .desk_show{
                                        display:flex !important;
                                    }
                                    }
                                    .mob_show_inr{
                                        display:flex !important;

                                    }
                                    .desk_show_inr{
                                        display:none !important;
                                    }
                                    @media(min-width:992px){
                                      
                                    .mob_show_inr{
                                        display:none !important;

                                    }  
                                    .desk_show_inr{
                                        display:flex !important;
                                    }
                                    }
                                </style>
                            <div class="card" id="profileslide" style=""
                                style="">
                                <div id="up">
                                    <i class="fa-sharp fa-solid fa-caret-up"></i>
                                </div>
                                <div class="card" id="namecard">
                                    <div> R. krishna</div>
                                    <div> Srii07255@gmail.com</div>
                                </div>
                                <div id="info">
                                    <div>
                                        <i class="fa-solid fa-user"></i>
                                    </div>
                                    <div id="para1">
                                        <button style="border: none;background: transparent;">Account Information</button>
                                        
                                    </div>
                                </div>
                                <div id="billing">
                                    <div>
                                        <i class="fa-solid fa-credit-card"></i>
                                    </div>
                                    <div id="para1">
                                    <button style="border: none;background: transparent;">Billing</button>
                                    </div>
                                </div>
                                <div id="help">
                                    <div id="qmark">
                                        <div>? </div>
                                    </div>
                                    <div id="para1">
                                    <button style="border: none;background: transparent;">Get Help</button> </div>
                                </div>
                                <div id="so-btn">
                                    <input type="button" value="Sign Out" class="form-control">
                                </div>
                            </div>
                        </li>
                        <li class="nav-item" style="">
                            <div
                                class="nav_c">
                                <i class="fa-solid fa-bag-shopping" nav_i></i>
                                <a class="nav-link nav_a"
                                    style=""
                                    href="cart.php">Cart</a>
                            </div>
                        </li>
                        <li class="nav-item mob_sign" style="">
                            <div class="nav_s">
                            <!-- <button class="btn_s form-control" type="button" style="color:#fff;background-color: rgba(12, 98, 175, 1);padding:10px;font-size: 16px; -->
    <!-- font-weight: 600;">sign out<
        
    /button> -->
                           
                                
                            </div>
                        </li>
                    </ul>
                </div>
                <div id="mob_close" style="position:fixed; right:0; top:0;height:100vh; width:100%;background:rgba(0,0,0,.4); z-index:200; display:flex; justify-content:end; opacity:0;transition:.5s;visibility:hidden">
                <div id="mob_close2" style="background:rgba(12, 98, 175, 1); width:300px;transform:translateX(100%); transition:.25s">
                <i style="position: absolute;top: 10px; right: 10px;font-size: 20px; " class="fa-solid fa-xmark" onclick="close_n()"></i>
                <ul class="navbar-nav mob_view" style="margin-top:40px;padding:20px">
                <li class="nav-item active" style="">
                            <a class="nav-link nav_a" href="#"
                                style=" ">
                                Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item" style="">
                            <a class="nav-link nav_a " href="#"
                                style=" ">FAQs</a>
                        </li>
                        <li class="nav-item" style="">
                            <a class="nav-link nav_a" href="#"
                                style="    ">Contact
                                </a>
                        </li>
                        <li>
                        <div  class="mob_show user_m">
                            <div id="profile ">
                                <button style="border:1px solid #fff; background: transparent;padding: 3px;border-radius: 5px;">
                                    <i  class="fa-solid fa-user nav_i" style="color:#fff"></i>
                                        <a href="ac-info.php" class="nav_a" style="font-size: 16px;color: #fff;align-items: center;width: 64px;text-decoration: none;font-weight:600px">Profile</a>
                                    </button>
                                    </div>
                            </div>
                        </li>
                        <li class="nav-item" style="">
                            <div
                                class="nav_c">
                                <i class="fa-solid fa-bag-shopping" nav_i></i>
                                <a class="nav-link nav_a"
                                    style=""
                                    href="cart.php">Cart</a>
                            </div>
                        </li>
                        <li class="nav-item mob_sign" style="">
                            <div class="nav_s">
                            <button class="btn_s form-control" type="button" style="color:rgba(12, 98, 175, 1);background-color:#fff;padding:10px;font-size: 16px; font-weight: 600;">sign out</button>
                           
                                
                            </div>
                        </li>


                 </ul>
               </div>   
                             
            </div>
        </div>
    </div>
</div>
<style>
   
</style>
<?php //include ("script.php")?>
<script>
    document.getElementById("profileslide").style.display = "none";

    function openprof() {
        document.getElementById("profileslide").style.display = "block";
    }
    
    document.addEventListener('mouseup', function (e) {
        var container = document.getElementById('profileslide');
        if (!container.contains(e.target)) {
            container.style.display = 'none';
        }
    });
</script>